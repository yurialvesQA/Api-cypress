package steps;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidElement;
import io.cucumber.java.pt.Dado;
import io.cucumber.java.pt.Então;
import io.cucumber.java.pt.Quando;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import page.*;
import utils.Utils;

import java.util.List;
import java.util.concurrent.TimeUnit;

import static utils.Utils.driver;

public class LoginSteps {
    LoginPage login = new LoginPage(driver);

    @Dado("^que eu informe usuário$")
    public void que_eu_informe_usuario() throws InterruptedException {
        login.emailLogin();
        driver.hideKeyboard();
        Hooks.captureScreenshot("pass", "que eu informe usuário");
    }
    @Dado("^que eu informe senha$")
    public void que_eu_informe_senha() throws InterruptedException {
        login.passwordLogin();
        driver.hideKeyboard();
        Hooks.captureScreenshot("pass", "que eu informe senha");
    }

    @Dado("^que eu informe usuário e senha$")
    public void que_eu_informe_usuario_e_senha() throws InterruptedException {
     //  driver.findElementByAccessibilityId("imp_emaillogin").click();
    //    driver.findElementByAccessibilityId("imp_emaillogin").sendKeys("yuri.alves@br.experian.com");


        login.emailLogin();
        login.passwordLogin();
        driver.hideKeyboard();
       // Thread.sleep(100);
      //  List<MobileElement> testes= driver.findElements(By.xpath("//android.view.View[@content-desc=\"imp_emaillogin\"]"));
    //    testes.get(0).click();

      //  driver.findElementByAccessibilityId("imp_emaillogin").click();
      //  Thread.sleep(20);

      //  Actions action = new Actions(driver);
   //     action.sendKeys("yuri@dfaskdfaska").perform();

   //     Thread.sleep(20);
     //   driver.findElementByAccessibilityId("imp_passwordlogin").click();
     //   Thread.sleep(20);

     //   action.sendKeys("testests").perform();
     //   Thread.sleep(1000);
        // Thread.sleep(7000);
     //   AndroidElement editElement = (AndroidElement) driver.findElement(By.xpath("//android.view.View[@content-desc=\"imp_emaillogin\"]"));
   //     editElement.click();
     //   Thread.sleep(30);
      //  driver.findElementByAccessibilityId("imp_emaillogin").sendKeys("estoutestandfasdla");
      //  driver.findElementByAccessibilityId("imp_emaillogin").sendKeys("yuri.alves@br.experian.com");
   //    MobileElement element = (MobileElement) driver.findElementsByXPath("//android.view.View[@content-desc=\"imp_emaillogin\"]");
    //    element.sendKeys("yurifda@fdksad.com");
    //   testes.get(0).sendKeys("testasetsaseas");


     //   MobileElement element = (MobileElement) driver.findElementsByXPath("//android.view.View[@content-desc=\"imp_emaillogin\"]");
     //   element.click();
       // element.setValue("Hello world!");
       // login.emailLogin();
     //   login.passwordLogin();
      //  driver.hideKeyboard();
    }

    @Quando("^eu clicar no botão logar$")
    public void eu_clicar_no_botão_logar() throws InterruptedException {
       login.confirmarLogin();
    }

    @Então("^vou visualizar a home do aplicativo$")
    public void vou_visualizar_a_home_do_aplicativo() throws InterruptedException {
        DocumentosPendentesPage documentosPendentesPage = new DocumentosPendentesPage(driver);
        HomePage homePage = new HomePage(driver);
        try{
            Assert.assertNotNull(homePage.campoHomePage());
        }catch (NoSuchElementException e){
            Assert.assertNotNull(documentosPendentesPage.campoEnviarDepois());
        }
    }

    @Então("^clicar no botão de usuário$")
    public void clicar_no_botao_de_usuario() throws InterruptedException {
        DocumentosPendentesPage documentosPendentesPage = new DocumentosPendentesPage(driver);
        HomePage homePage = new HomePage(driver);
        try{
            documentosPendentesPage.campoEnviarDepois();
            homePage.irParaMinhaConta();
        }catch (NoSuchElementException e){
            homePage.irParaMinhaConta();
        }
    }

    @Então("visualizo a mensagem de campo senha obrigatória")
    public void visualizoAMensagemDeCampoSenhaObrigatoria() throws InterruptedException {
        Assert.assertNotNull(login.mensagemCampoSenhaObrigatorio());
    }

    @Então("visualizo a mensagem de campo email obrigatório")
    public void visualizoAMensagemDeCampoEmailObrigatorio() throws InterruptedException {
        Assert.assertNotNull(login.mensagemCampoEmailObrigatorio());
    }

    @Dado("que eu clico no botão esqueci minha senha")
    public void queEuClicoNoBotaoEsqueciMinhaSenha() throws InterruptedException {
        login.irParaPaginaEsqueciMinhaSenha();
    }

    @Quando("preencher o email de recuperação de senha")
    public void preencherOEmailDeRecuperacaoDeSenha() throws InterruptedException {
        EsqueciMinhaSenhaPage esqueciMinhaSenhaPage = new EsqueciMinhaSenhaPage(driver);
        esqueciMinhaSenhaPage.preencherEmail();
    }

    @Então("clico em enviar email de recuperação de senha")
    public void clicoEmEnviarEmailDeRecuperacaoDeSenha() throws InterruptedException {
        EsqueciMinhaSenhaPage esqueciMinhaSenhaPage = new EsqueciMinhaSenhaPage(driver);
        esqueciMinhaSenhaPage.enviarEmail();
    }

    @Dado("que eu clico no botão recuperar token")
    public void queEuClicoNoBotaoRecuperarToken() throws InterruptedException {
        login.irParaPaginaRecuperarToken();
    }

    @Dado("que eu clico no botão Tokens")
    public void queEuClicoNoBotaoTokens() throws InterruptedException {
        login.irParaPaginaTokens();
    }

    @Quando("preencher o email de recuperação de token")
    public void preencherOEmailDeRecuperacaoDeToken() throws InterruptedException {
        RecuperarTokenPage recuperarTokenPage = new RecuperarTokenPage(driver);
        recuperarTokenPage.preencherEmail();
    }

    @Quando("preencher a senha de recuperação de token")
    public void preencherASenhaDeRecuperacaoDeToken() throws InterruptedException {
        RecuperarTokenPage recuperarTokenPage = new RecuperarTokenPage(driver);
        recuperarTokenPage.preencherSenha();
    }

    @Então("clico em enviar código de recuperação de token")
    public void clicoEmEnviarCodigoDeRecuperacaoDeToken() {
        RecuperarTokenPage recuperarTokenPage = new RecuperarTokenPage(driver);
        recuperarTokenPage.enviarCodigoRecuperacaoToken();
    }

    @Então("verifico que a página Tokens está sendo exibida")
    public void verificoQueAPaginaTokensEstaSendoExibida() throws InterruptedException {
        TokensPage tokensPage = new TokensPage(driver);
        Assert.assertNotNull(tokensPage.campoHeadersToken());
    }

    @Quando("eu clicar em lembrar email")
    public void euClicarEmLembrarEmail() throws InterruptedException {
        login.clicarLembrarEmail();
    }

    @Dado("que eu faço login com usuario de transferencia")
    public void queEuFacoLoginComUsuarioDeTransferencia() throws InterruptedException {
        login.emailLoginTransferencia();
        login.passwordLoginTransferencia();
    }

    @Dado("que eu faço login com usuario de termo de uso")
    public void queEuFacoLoginComUsuarioDeTermoDeUso() throws InterruptedException {
        login.emailLoginTermoDeUso();
        login.passwordLoginTermoDeUso();
    }
}
