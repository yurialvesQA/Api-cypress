package steps;

import io.cucumber.java.pt.E;
import io.cucumber.java.pt.Então;
import org.junit.Assert;
import page.ExtratoPage;
import page.HomePage;
import page.MenuPage;
import page.PagamentosPage;

import static utils.Utils.driver;

public class PagamentosSteps {
    PagamentosPage pagamentosPage = new PagamentosPage(driver);


    @E("clicar em pagamentos")
    public void clicarEmPagamentos() throws InterruptedException {
        MenuPage menuPage = new MenuPage(driver);
        menuPage.irParaPagamentos();
        Hooks.captureScreenshot("pass", "clicar em menu");
    }

    @E("clicar em pagar boletos")
    public void clicarEmPagarBoletos() throws InterruptedException {
        pagamentosPage.clicoNaOpcaoPagarBoletos();
    }

    @E("clicar em consultar pagamentos")
    public void clicarEmConsultarPagamentos() throws InterruptedException {
        pagamentosPage.clicoNaOpcaoConsultarPagamentos();
    }

    @E("clicar em buscador de boletos")
    public void clicarEmBuscadorBoletos() throws InterruptedException {
        pagamentosPage.clicoNaOpcaoBuscadorBoletos();
    }

    @Então("verifico que possui o elemento status de boleto")
    public void verificoQuePossuiStatusBoleto() {
        Assert.assertTrue(pagamentosPage.possuiElementoStatus());
    }

    @Então("verifico que possui um boleto listado")
    public void verificoQuePossuiBoletoListado() {
        Assert.assertTrue(pagamentosPage.possuiElementoBoleto());
    }

    @Então("verifico que possui camera código de barras")
    public void verificoQuePossuiCameraCodigoBarras() {
        Assert.assertTrue(pagamentosPage.possuiElementoPosicioneCodigoBarras());
    }
}