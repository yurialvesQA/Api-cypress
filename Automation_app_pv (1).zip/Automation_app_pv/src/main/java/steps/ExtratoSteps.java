package steps;

import io.cucumber.java.pt.E;
import io.cucumber.java.pt.Então;
import org.junit.Assert;
import page.ExtratoPage;
import page.HomePage;
import page.MenuPage;

import static utils.Utils.driver;

public class ExtratoSteps {
    ExtratoPage extratoPage = new ExtratoPage(driver);

    @E("clicar em extrato")
    public void clicarEmExtrato() throws InterruptedException {
        MenuPage menuPage = new MenuPage(driver);
        menuPage.irParaExtrato();
        Hooks.captureScreenshot("pass", "clicar em extrato");
    }

    @Então("verifico que possui pix recebido")
    public void verificoQuePossuiPixRecebido() {
        Assert.assertTrue(extratoPage.possuiPixRecebido());
        Hooks.captureScreenshot("pass", "verifico que possui pix recebido");
    }

    @E("volto {string} meses")
    public void voltoMeses(String meses) throws InterruptedException {
        extratoPage.clicoNoIconeCalendario();
        extratoPage.clicoEmVoltarMes(Integer.parseInt(meses));
        extratoPage.clicoNoDia10();
        extratoPage.clicoNoDia11();
        extratoPage.clicoNoBotaoOkCalendario();
        Hooks.captureScreenshot("pass", "volto "+meses+" meses");
    }

    @Então("verifico a mensagem que não encontramos lançamentos nesse período")
    public void verificoAMensagemQueNaoEncontramosLancamentosNessePeriodo() {
        try {
            Assert.assertNotNull(extratoPage.textoNaoEncontramosLancamentos());
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        Hooks.captureScreenshot("pass", "verifico a mensagem que não encontramos lançamentos nesse período");
    }
}
