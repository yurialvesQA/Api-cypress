package steps;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import io.appium.java_client.MobileDriver;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.apache.commons.io.FileUtils;
import org.junit.Rule;
import org.junit.rules.TestName;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import reporter.ExtentManager;
import utils.Utils;

import java.io.File;
import java.io.IOException;

import static utils.Utils.acessarApp;
import static utils.Utils.driver;

public class Hooks {

    @Rule
    public TestName testName = new TestName();

    public static ExtentReports extent;
    public static ExtentTest test;

    @Before
    public static void setUp(Scenario cenario) throws Exception {
        extent = ExtentManager.getInstance();
        test = extent.createTest(cenario.getName(), cenario.getName());
        acessarApp();

    }

    @After
    public static void fecharApp(Scenario cenario) throws Exception{
        if(cenario.isFailed()){
            captureScreenshot("fail","final");
        }else{
            captureScreenshot("pass","final");
        }
        extent.flush();
        driver.quit();
    }

    public static void captureScreenshot(String status, String step){
        try{
            TakesScreenshot ts = (TakesScreenshot) driver;
            byte[] screenshotBytes = ts.getScreenshotAs(OutputType.BYTES);
            String screenshotPath = "screenshots/"+System.currentTimeMillis()+".png";
            FileUtils.writeByteArrayToFile(new File(screenshotPath), screenshotBytes);
            if(status.equals("pass")){
                Hooks.test.pass(step, MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
            }else{
                Hooks.test.fail(step,MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }


    /**
     * Retorna o browser inicialzado
     *
     * @return
     */
    public static WebDriver getDriver() {
        return driver;
    }
}
