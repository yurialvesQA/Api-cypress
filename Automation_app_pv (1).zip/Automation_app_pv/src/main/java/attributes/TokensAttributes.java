package attributes;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class TokensAttributes {
    @AndroidFindBy(xpath = "//android.widget.TextView[@text=\"Tokens\"]")
    protected MobileElement headerTokens;
}
