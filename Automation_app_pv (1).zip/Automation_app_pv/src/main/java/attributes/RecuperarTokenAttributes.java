package attributes;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class RecuperarTokenAttributes {
    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"imp_emailrecovery\"]/android.widget.EditText")
    protected MobileElement email;

    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"imp_passwordrecovery\"]/android.widget.EditText")
    protected MobileElement senha;

    @AndroidFindBy(accessibility = "btn_recoverytoken")
    protected MobileElement botaoEnviarCodigo;
}
