package attributes;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebDriver;

public class DocumentosPendentesAttributes{

    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"ENVIAR DEPOIS\"]")
    protected MobileElement enviarDepois;
}
