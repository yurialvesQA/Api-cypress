package attributes;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class ExtratoAttributes {
    @AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,\"Pix Recebido\")]")
    protected MobileElement pixRecebido;

    @AndroidFindBy(xpath = "//android.widget.ImageView")
    protected MobileElement iconeCalendario;

    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"Dismiss\"]/android.view.View/android.view.View/android.view.View/android.widget.Button[1]")
    protected MobileElement voltarMes;

    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"10\"]")
    protected MobileElement dia10;

    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"11\"]")
    protected MobileElement dia11;

    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"OK\"]")
    protected MobileElement botaoOkCalendario;

    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"Ops! Não encontramos lançamentos nesse período! :(\"]")
    protected MobileElement textoNaoEncontramosLancamentos;
}
