package attributes;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class PixAttributes {
    @AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc=\"Transferir\"]")
    protected MobileElement transferir;

    @AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc=\"QR Code\"]")
    protected MobileElement QRCode;

    @AndroidFindBy(xpath = "//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View[2]")
    protected MobileElement botaoDigitarCodigoQRCode;

    @AndroidFindBy(xpath = "//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View[2]")
    protected MobileElement botaoContinuarDinheiroNaMaoPixSaqueTroco;

    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"btn_journeypix\"]")
    protected MobileElement botaoContinuarJornadaPix;

    @AndroidFindBy(xpath = "//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View[2]")
    protected MobileElement botaoContinuarJornadaPixOutraVersao;

    @AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc=\"Pix Copia\n" +
            "e Cola\"]")
    protected MobileElement pixCopiaECola;

    @AndroidFindBy(xpath = "//android.widget.EditText")
    protected MobileElement inputCodigoPix;

    @AndroidFindBy(xpath = "//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View[4]")
    protected MobileElement inputNovoQRCode;

    @AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc=\"Receber Pix\"]")
    protected MobileElement receberPix;

    @AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc=\"Extrato Pix\"]")
    protected MobileElement extratoPix;

    @AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc=\"Contatos\n" +
            "Confiáveis\"]")
    protected MobileElement contatos;

    @AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc=\"Minhas\n" +
            "Chaves\"]")
    protected MobileElement minhasChaves;

    @AndroidFindBy(xpath = "//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View[2]")
    protected MobileElement continuarSegurancaChavesPix;

    @AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc=\"Limites\"]")
    protected MobileElement limites;

    @AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc=\"Reclame\n" +
            "Aqui\"]")
    protected MobileElement reclameAquiPix;

    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"LANÇAMENTOS\"]")
    protected MobileElement lancamentosExtratoPix;

    @AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc=\"Para Pessoas\"]")
    protected MobileElement limitePessoasPix;

    @AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc=\"Para Empresas\"]")
    protected MobileElement limiteEmpresasPix;

    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"Atendimento\n" +
            "PagueVeloz\"]")
    protected MobileElement opcaoAtendimentoReclamePixPagueVeloz;

    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"Atendimento\n" +
            "Banco Central\n" +
            "do Brasil\"]")
    protected MobileElement opcaoAtendimentoReclamePixBancoCentralBrasil;

    @AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc=\"Contatos Confiáveis\"]")
    protected MobileElement limiteContatosConfiaveisPix;

    @AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc=\"Saque e Troco\"]")
    protected MobileElement limiteSaqueETrocoPix;

    @AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc=\"Gestão de Horários\"]")
    protected MobileElement limiteGestaoHorariosPix;

    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"FUTUROS\"]")
    protected MobileElement futurosExtratoPix;

    @AndroidFindBy(xpath = "//android.widget.ScrollView/android.view.View[2]/android.view.View/android.view.View[1]")
    protected MobileElement primeiraChavePix;

    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"TODOS\"]")
    protected MobileElement todosExtratoPix;

    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"ENTRADAS\"]")
    protected MobileElement entradasExtratoPix;

    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"SAÍDAS\"]")
    protected MobileElement saidasExtratoPix;

    @AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc=\"teste sim\n" +
            "435.122.370-70\"]")
    protected MobileElement contatosConfiaveisPix;

    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"Manual\"]")
    protected MobileElement tipoChaveManual;

    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"Pagamento efetuado\n" +
            "com sucesso! :)\"]")
    protected MobileElement mensagemPagamentoEfetuadoComSucesso;

    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"OK\"]")
    protected MobileElement botaoOkEfetuadoComSucesso;

    @AndroidFindBy(xpath = "//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View[3]")
    protected MobileElement confirmoODestinatarioPix;

    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"R$ 0,01\"]")
    protected MobileElement valorComprovantePagamento;

    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"Yuri Alves\"]")
    protected MobileElement nomeDestinatarioYuriAlves;

    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"PremierSoft\"]")
    protected MobileElement nomePagadorPremierSoft;

    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"SIM\"]")
    protected MobileElement confirmoATransferenciaPix;

    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"Celular\"]")
    protected MobileElement tipoChaveCelular;

    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"CPF\"]")
    protected MobileElement tipoChaveCPF;

    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"CNPJ\"]")
    protected MobileElement tipoChaveCNPJ;

    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"E-mail\"]")
    protected MobileElement tipoChaveEmail;

    @AndroidFindBy(xpath = "//android.widget.EditText")
    protected MobileElement campoChavePix;

    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"Informações do Destinatário\n" +
            "Nome:\n" +
            "Yuri Alves\n" +
            "CPF:\n" +
            "***.542.348-**\n" +
            "Instituição:\n" +
            "PAGUEVELOZ IP LTDA.\"]/android.widget.EditText[1]")
    protected MobileElement campoValorPix;

    @AndroidFindBy(xpath = "//android.widget.ImageView")
    protected MobileElement pesquisarChavePix;

    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"Chave Aleatória\"]")
    protected MobileElement tipoChaveAleatoria;

    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"Selecione a Chave\"]")
    protected MobileElement botaoSelecioneAChave;
}
