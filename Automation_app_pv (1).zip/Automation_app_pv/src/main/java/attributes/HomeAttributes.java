package attributes;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class HomeAttributes {
    @AndroidFindBy(accessibility = "btn_home")
    protected MobileElement homeButton;

    @AndroidFindBy(accessibility = "pct_imguser")
    protected MobileElement imgUser;

    @AndroidFindBy(accessibility = "btn_visiblebalance")
    protected MobileElement verSaldo;

    @AndroidFindBy(accessibility = "btn_menu")
    protected MobileElement menuButton;

    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"Pular\"]")
    protected MobileElement pularDica;

    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"btn_updateclose\"]")
    protected MobileElement atualizacaoPendente;
}
