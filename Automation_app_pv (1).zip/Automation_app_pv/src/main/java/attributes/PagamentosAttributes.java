package attributes;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class PagamentosAttributes {
    @AndroidFindBy(xpath = "//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View[2]/android.widget.ImageView[1]")
    protected MobileElement pagarBoletos;

    @AndroidFindBy(xpath = "//android.widget.ImageView[contains(@content-desc,\"Consultar pagamentos\")]")
    protected MobileElement consultarPagamentos;

    @AndroidFindBy(xpath = "//android.widget.ImageView[contains(@content-desc,\"Buscador de boletos\")]")
    protected MobileElement buscadorBoletos;

    @AndroidFindBy(xpath = "//android.widget.ImageView[contains(@content-desc,\"Limites para Pagamento\")]")
    protected MobileElement limitesPagamento;

    @AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,\"Cod. barras\")]")
    protected MobileElement codigoBarrasBoleto;

    @AndroidFindBy(xpath = "//android.widget.SeekBar")
    protected MobileElement barraLimite;

    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"Posicione o código de barras na marcação\"]")
    protected MobileElement posicioneCodigoBarras;

    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"Status\"]")
    protected MobileElement statusPagamentos;
}
