package page;

import attributes.ExtratoAttributes;
import attributes.MenuAttributes;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.PageFactory;
import utils.BasePage;

import java.time.LocalDate;

public class ExtratoPage extends ExtratoAttributes {
    LocalDate myObj = LocalDate.now();

    public ExtratoPage(AppiumDriver<?> driver) {
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }

    public boolean possuiPixRecebido() {
        try{
            BasePage.implicitWait(pixRecebido, 10);
            return true;
        }catch (NoSuchElementException e){
            return false;
        }
    }

    public void clicoNoIconeCalendario() throws InterruptedException {
        BasePage.implicitWait(iconeCalendario, 10);
        iconeCalendario.click();
    }

    public void clicoEmVoltarMes(int vezes) throws InterruptedException {
        BasePage.implicitWait(voltarMes, 10);
        for(int i=0;i<vezes;i++){
            voltarMes.click();
        }
    }

    public void clicoNoDia10() throws InterruptedException {
        BasePage.implicitWait(dia10, 10);
        dia10.click();
    }
    public void clicoNoDia11() throws InterruptedException {
        BasePage.implicitWait(dia11, 10);
        dia11.click();
    }

    public void clicoNoBotaoOkCalendario() throws InterruptedException {
        BasePage.implicitWait(botaoOkCalendario, 10);
        botaoOkCalendario.click();
    }

    public MobileElement textoNaoEncontramosLancamentos() throws InterruptedException {
        BasePage.implicitWait(textoNaoEncontramosLancamentos, 10);
        return textoNaoEncontramosLancamentos;
    }

}
