package page;

import attributes.EsqueciMinhaSenhaAttributes;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import utils.BasePage;

import java.time.LocalDate;

import static utils.Utils.getPropertySettings;

public class EsqueciMinhaSenhaPage  extends EsqueciMinhaSenhaAttributes {

    LocalDate myObj = LocalDate.now();

    public EsqueciMinhaSenhaPage(AppiumDriver<?> driver) {
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }

    public MobileElement campoEmail() throws InterruptedException {
        BasePage.implicitWait(email, 10);
        return email;
    }

    public void preencherEmail() throws InterruptedException {
        BasePage.implicitWait(email, 10);
        email.sendKeys(getPropertySettings("PvMobile.data.emailuser"));
    }

    public void enviarEmail() throws InterruptedException {
        BasePage.implicitWait(email, 10);
        botaoEnviar.click();
    }
}
