package page;

import attributes.HomeAttributes;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.PageFactory;
import utils.BasePage;
import utils.Utils;

import java.time.LocalDate;

public class HomePage  extends HomeAttributes {

    LocalDate myObj = LocalDate.now();

    public HomePage(AppiumDriver<?> driver) {
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }

    public MobileElement campoHomePage() throws InterruptedException {
        BasePage.implicitWait(homeButton, 10);
        return homeButton;
    }

    public MobileElement irParaMinhaConta() throws InterruptedException {
        BasePage.implicitWait(imgUser, 10);
        imgUser.click();
        return imgUser;
    }

    public void irParaHome(AppiumDriver<MobileElement> driver) throws InterruptedException {
        DocumentosPendentesPage docPendentes = new DocumentosPendentesPage(driver);
        try {
            BasePage.implicitWait(atualizacaoPendente, 15);
            atualizacaoPendente.click();
            Thread.sleep(2000);
            BasePage.implicitWait(docPendentes.campoEnviarDepois(), 15);
            docPendentes.clicarEnviarDepois();
            Thread.sleep(2000);
            BasePage.implicitWait(pularDica, 15);
            pularDica.click();
        } catch (NoSuchElementException e) {
            try {
                BasePage.implicitWait(docPendentes.campoEnviarDepois(), 15);
                docPendentes.clicarEnviarDepois();
                Thread.sleep(2000);
                BasePage.implicitWait(pularDica, 15);
                pularDica.click();
            }catch (NoSuchElementException e2) {
                BasePage.implicitWait(pularDica, 15);
                pularDica.click();
            }
        }
    }

    public void irParaMenu() throws InterruptedException {
        BasePage.implicitWait(menuButton, 10);
        menuButton.click();
    }
}
