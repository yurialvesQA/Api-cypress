package page;

import attributes.TokensAttributes;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import utils.BasePage;

import java.time.LocalDate;

import static utils.Utils.getPropertySettings;

public class TokensPage  extends TokensAttributes {

    LocalDate myObj = LocalDate.now();

    public TokensPage(AppiumDriver<?> driver) {
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }

    public MobileElement campoHeadersToken() throws InterruptedException {
        BasePage.implicitWait(headerTokens, 10);
        return headerTokens;
    }

}
