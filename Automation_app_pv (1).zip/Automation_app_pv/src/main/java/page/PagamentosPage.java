package page;

import attributes.PagamentosAttributes;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import utils.BasePage;
import utils.Utils;

import java.time.LocalDate;

public class PagamentosPage extends PagamentosAttributes {
    LocalDate myObj = LocalDate.now();

    public PagamentosPage(AppiumDriver<?> driver) {
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }

    public void clicoNaOpcaoPagarBoletos() throws InterruptedException {
        BasePage.implicitWait(pagarBoletos, 10);
        BasePage.fixedWait(6);
        Actions action = new Actions(Utils.driver);
        action.moveToElement(pagarBoletos).click().perform();
    }

    public void clicoNaOpcaoConsultarPagamentos() throws InterruptedException {
        BasePage.implicitWait(consultarPagamentos, 10);
        consultarPagamentos.click();
    }

    public void clicoNaOpcaoBuscadorBoletos() throws InterruptedException {
        BasePage.implicitWait(buscadorBoletos, 10);
        buscadorBoletos.click();
    }

    public void clicoNaOpcaoLimitesPagamento() throws InterruptedException {
        BasePage.implicitWait(limitesPagamento, 10);
        limitesPagamento.click();
    }

    public boolean possuiElementoStatus(){
        try{
            BasePage.implicitWait(statusPagamentos, 10);
            return true;
        }catch (NoSuchElementException e){
            return false;
        }
    }

    public boolean possuiElementoBoleto(){
        try{
            BasePage.implicitWait(codigoBarrasBoleto, 10);
            return true;
        }catch (NoSuchElementException e){
            return false;
        }
    }

    public boolean possuiElementoPosicioneCodigoBarras(){
        try{
            BasePage.implicitWait(posicioneCodigoBarras, 10);
            return true;
        }catch (NoSuchElementException e){
            return false;
        }
    }
}
