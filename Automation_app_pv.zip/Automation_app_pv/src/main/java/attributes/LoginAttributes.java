package attributes;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebDriver;

public class LoginAttributes {

    @AndroidFindBy(xpath = "//hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[1]")
    @iOSFindBy(accessibility = "E-mail")
    protected MobileElement campoemail;

    @AndroidFindBy(xpath = "//hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[2]")
    @iOSFindBy(accessibility = "Senha")
    protected MobileElement camposenha;

    @AndroidFindBy(accessibility = "ACESSAR CONTA")
    @iOSFindBy(accessibility = "ACESSAR CONTA")
    protected MobileElement botaologin;


}
