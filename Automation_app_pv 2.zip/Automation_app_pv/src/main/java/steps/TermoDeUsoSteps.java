package steps;

import io.cucumber.java.pt.E;
import io.cucumber.java.pt.Então;
import org.junit.Assert;
import page.*;

import static utils.Utils.driver;

public class TermoDeUsoSteps {
    TermoDeUsoPage termoDeUsoPage = new TermoDeUsoPage(driver);

    @E("eu clico no botão de aceitar termo de uso")
    public void clicarAceitarTermoDeUso() throws InterruptedException {
        termoDeUsoPage.clicarBotaoAceitar();
        Hooks.captureScreenshot("pass", "eu clico no botão de aceitar termo de uso");
    }

    @Então("eu clico no botão de recusar termo de uso")
    public void euClicoNoBotaoDeRecusarTermoDeUso() throws InterruptedException {
        termoDeUsoPage.clicarBotaoRecusar();
        Hooks.captureScreenshot("pass", "eu clico no botão de recusar termo de uso");
    }

    @Então("eu clico no botão de confirmar ação negar")
    public void euClicoNoBotaoConfirmarAcaoNegar() throws InterruptedException {
        termoDeUsoPage.botaoConfirmarAcaoNegar();
        Hooks.captureScreenshot("pass", "eu clico no botão de confirmar ação negar");
    }
}
