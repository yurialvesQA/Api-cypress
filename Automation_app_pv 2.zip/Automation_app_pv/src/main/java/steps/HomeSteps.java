package steps;

import io.cucumber.java.pt.E;
import io.cucumber.java.pt.Quando;
import page.HomePage;
import page.LoginPage;

import static utils.Utils.driver;

public class HomeSteps {
    HomePage home = new HomePage(driver);

    @Quando("eu estiver no home")
    public void euEstiverNoHome() throws InterruptedException {
        home.irParaHome(driver);
        Hooks.captureScreenshot("pass", "eu estiver no home");
    }

    @E("clicar em menu")
    public void clicarEmMenu() throws InterruptedException {
        home.irParaMenu();
        Hooks.captureScreenshot("pass", "clicar em menu");
    }

}
