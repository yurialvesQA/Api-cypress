package steps;


import io.cucumber.java.pt.E;
import io.cucumber.java.pt.Então;
import org.junit.Assert;
import page.ExtratoPage;
import page.HomePage;
import page.MenuPage;
import page.PixPage;
import utils.Utils;

import static utils.Utils.driver;

public class PixSteps {
    PixPage pixPage = new PixPage(driver);

    @E("clicar em pix")
    public void clicarEmPix() throws InterruptedException {
        MenuPage menuPage = new MenuPage(driver);
        menuPage.irParaPix();
        Hooks.captureScreenshot("pass", "clicar em pix");
    }

    @E("clicar em transferir pix")
    public void clicarEmTransferirPix() throws InterruptedException {
        pixPage.clicoEmTransferir();
        Hooks.captureScreenshot("pass", "clicar em transferir pix");
    }

    @Então("verifico as opções do menu pix")
    public void verificoAsOpcoesDoMenuPix() {
        try {
            Assert.assertNotNull(pixPage.limitesElemento());
            Assert.assertNotNull(pixPage.contatosConfiaveisElemento());
            Assert.assertNotNull(pixPage.extratoElemento());
            Assert.assertNotNull(pixPage.pixCopiaEColaElemento());
            Assert.assertNotNull(pixPage.qrCodeElemento());
            Assert.assertNotNull(pixPage.transferirElemento());
            Assert.assertNotNull(pixPage.receberElemento());
            Assert.assertNotNull(pixPage.minhasChavesElemento());
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        Hooks.captureScreenshot("pass", "verifico as opções do menu pix");
    }

    @Então("verifico as opções de chave pix")
    public void verificoAsOpcoesDeChave() {
        Assert.assertTrue(pixPage.possuiOpcoesDeTipoDeChave());
        Hooks.captureScreenshot("pass", "verifico as opções de chave pix");
    }

    @E("clicar em selecione a chave")
    public void clicarEmSelecioneAChave() throws InterruptedException {
        pixPage.clicoEmSelecioneAChave();
        Hooks.captureScreenshot("pass", "clicar em selecione a chave");
    }

    @E("clicar em QR Code pix")
    public void clicarEmQRCodePix() throws InterruptedException {
        pixPage.clicoEmQRCode();
        Hooks.captureScreenshot("pass", "clicar em QR Code pix");
    }

    @E("clicar em continuar dinheiro na mão com pix saque e troco")
    public void clicarEmContinuarDinheiroNaMaoComPixSaqueETroco() throws InterruptedException {
        pixPage.clicoEmContinuarDinheiroNaMaoComPixSaqueETroco();
        Hooks.captureScreenshot("pass", "clicar em continuar dinheiro na mão com pix saque e troco");
    }

    @Então("verifico se abriu a câmera para escanear o QR Code pix")
    public void verificoSeACameraEstaAberta() throws InterruptedException {
        try {
            Assert.assertNotNull(pixPage.botaoDigitarCodigoQRCode());
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        Hooks.captureScreenshot("pass", "verifico se abriu a câmera para escanear o QR Code pix");
    }

    @E("clicar em continuar jornada pix")
    public void clicarEmContinuarJornadaPix() throws InterruptedException {
        pixPage.clicoEmContinuarJornadaPix();
        Hooks.captureScreenshot("pass", "clicar em continuar jornada pix");
    }

    @E("clicar em pix copia e cola")
    public void clicarEmPixCopiaECola() throws InterruptedException {
        pixPage.clicoEmPixCopiaECola();
        Hooks.captureScreenshot("pass", "clicar em pix copia e cola");
    }

    @E("clicar em receber pix")
    public void clicarEmReceberPix() throws InterruptedException {
        pixPage.clicoEmReceberPix();
        Hooks.captureScreenshot("pass", "clicar em receber pix");
    }

    @E("clicar em extrato pix")
    public void clicoEmExtratoPix() throws InterruptedException {
        pixPage.clicoEmExtratoPix();
        Hooks.captureScreenshot("pass", "clicar em extrato pix");
    }

    @E("clicar em contatos confiaveis pix")
    public void clicoEmContatosConfiaveisPix() throws InterruptedException {
        pixPage.clicoEmContatosConfiaveisPix();
        Hooks.captureScreenshot("pass", "clicar em contatos confiaveis pix");
    }

    @E("clicar em minhas chaves pix")
    public void clicoEmMinhasChavesPix() throws InterruptedException {
        pixPage.clicoEmMinhasChavesPix();
        Hooks.captureScreenshot("pass", "clicar em minhas chaves pix");
    }

    @E("clicar em meus limites pix")
    public void clicoEmMeusLimitesPix() throws InterruptedException {
        pixPage.clicoEmLimitesPix();
        Hooks.captureScreenshot("pass", "clicar em meus limites pix");
    }

    @E("clicar em continuar na mensagem de segurança chaves pix")
    public void clicoEmContinuarMensagemSegurancaPix() throws InterruptedException {
        pixPage.clicoContinuarSegurancaChavesPix();
        Hooks.captureScreenshot("pass", "clicar em continuar na mensagem de segurança chaves pix");
    }

    @Então("verifico o input de digitar o código pix")
    public void verificoOInputDeDigitarOCodigoPix() throws InterruptedException {
        Assert.assertNotNull(pixPage.inputCodigoPix());
        Hooks.captureScreenshot("pass", "verifico o input de digitar o código pix");
    }

    @Então("verifico o input de novo QRCode receber")
    public void verificoOInputDeNovoQRCodeReceber() throws InterruptedException {
        Assert.assertNotNull(pixPage.inputNovoQRCode());
        Hooks.captureScreenshot("pass", "verifico o input de novo QRCode receber");
    }

    @Então("verifico os botões de extrato pix")
    public void verificoOsBotoesDeExtratoPix() {
        try {
            Assert.assertNotNull(pixPage.lancamentosExtratoPix());
            Assert.assertNotNull(pixPage.futurosExtratoPix());
            Assert.assertNotNull(pixPage.todosExtratoPix());
            Assert.assertNotNull(pixPage.entradasExtratoPix());
            Assert.assertNotNull(pixPage.saidasExtratoPix());
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        Hooks.captureScreenshot("pass", "verifico os botões de extrato pix");
    }

    @Então("verifico os contatos confiaveis pix")
    public void verificoOsContatosConfiaveisPix() {
        try {
            Assert.assertNotNull(pixPage.contatosConfiaveisPix());
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        Hooks.captureScreenshot("pass", "verifico os contatos confiaveis pix");
    }

    @Então("verifico que existem chaves pix")
    public void verificoQueExistemChavesPix() {
        try {
            Assert.assertNotNull(pixPage.primeiraChavePix());
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        Hooks.captureScreenshot("pass", "verifico que existem chaves pix");
    }

    @Então("verifico as opções de limite pix")
    public void verificoAsOpcoesDeLimitePix() {
        try {
            Assert.assertNotNull(pixPage.limiteSaqueETrocoPix());
            Assert.assertNotNull(pixPage.limitePessoasPix());
            Assert.assertNotNull(pixPage.limiteEmpresasPix());
            Assert.assertNotNull(pixPage.limiteContatosConfiaveisPix());
            Assert.assertNotNull(pixPage.limiteGestaoHorariosPix());
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        Hooks.captureScreenshot("pass", "verifico as opções de limite pix");
    }

    @E("clicar em reclame aqui pix")
    public void clicarEmReclameAquiPix() throws InterruptedException {
        pixPage.clicoEmReclameAquiPix();
        Hooks.captureScreenshot("pass", "clicar em reclame aqui pix");
    }

    @Então("verifico as opções de atendimento reclame aqui")
    public void verificoAsOpcoesDeAtendimentoReclameAqui() {
        try {
            Assert.assertNotNull(pixPage.opcaoAtendimentoReclamePixPagueVeloz());
            Assert.assertNotNull(pixPage.opcaoAtendimentoReclamePixBancoCentralBrasil());
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        Hooks.captureScreenshot("pass", "verifico as opções de atendimento reclame aqui");
    }

    @E("clicar em selecione a chave {string}")
    public void clicarEmSelecioneAChave(String tipoChave) throws InterruptedException {
        pixPage.clicoEmSelecioneAChave();

    }

    @E("clicar em cpf chave pix")
    public void clicarEmCpfChavePix() throws InterruptedException {
        pixPage.clicoEmTipoChaveCPF();
        Hooks.captureScreenshot("pass", "clicar em cpf chave pix");
    }

    @E("digito o cpf chave pix")
    public void digitoOCpfChavePix() throws InterruptedException {
        pixPage.digitoCpfChavePix();
        pixPage.clicoEmPesquisarChavePix();
        Hooks.captureScreenshot("pass", "digito o cpf chave pix");
    }

    @E("confirmo o destinatario pix")
    public void confirmoODestinatarioPix() {
        pixPage.confirmoODestinatarioPix();
        Hooks.captureScreenshot("pass", "confirmo o destinatario pix");
    }

    @E("coloco o valor {string} pix")
    public void colocoOValorPix(String valor) throws InterruptedException {
        pixPage.colocoOValorPix(valor);
        Hooks.captureScreenshot("pass", "coloco o valor "+valor+" pix");
    }

    @Então("confirmo a transferencia pix")
    public void confirmoATransferenciaPix() {
        pixPage.confirmoATransferenciaPix();
        Hooks.captureScreenshot("pass", "confirmo a transferencia pix");
    }

    @Então("verifico a mensagem de pagamento efetuado com sucesso")
    public void verificoAMensagemDePagamentoEfetuadoComSucesso() {
        Assert.assertNotNull(pixPage.mensagemPagamentoEfetuadoComSucesso());
        pixPage.clicoNaMensagemPagamentoEfetuadoComSucesso();
        Assert.assertNotNull(pixPage.valorComprovantePagamento());
        Assert.assertNotNull(pixPage.nomeDestinatarioYuriAlves());
        Assert.assertNotNull(pixPage.nomePagadorPremierSoft());
        Hooks.captureScreenshot("pass", "verifico a mensagem de pagamento efetuado com sucesso");
    }
}