package attributes;

public class MinhaContaAttributes {
}
