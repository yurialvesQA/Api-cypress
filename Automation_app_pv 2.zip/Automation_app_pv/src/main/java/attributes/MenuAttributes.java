package attributes;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class MenuAttributes {
    @AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc=\"Extrato\"]")
    protected MobileElement extrato;

    @AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc=\"Pagamentos\"]")
    protected MobileElement pagamentos;

    @AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc=\"Pix\"]")
    protected MobileElement pix;
}
