package attributes;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class TermoDeUsoAttributes {
    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"btn_acceptterm\"]")
    protected MobileElement botaoAceitar;

    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"btn_denyterm\"]")
    protected MobileElement botaoRecusar;

    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"NEGAR\"]")
    protected MobileElement botaoConfirmarAcaoNegar;
}
