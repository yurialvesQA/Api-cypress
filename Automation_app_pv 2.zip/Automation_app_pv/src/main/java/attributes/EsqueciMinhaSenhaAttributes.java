package attributes;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class EsqueciMinhaSenhaAttributes {
    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"imp_forgotpassword\"]/android.widget.EditText")
    protected MobileElement email;

    @AndroidFindBy(accessibility = "btn_forgotpassword")
    protected MobileElement botaoEnviar;
}
