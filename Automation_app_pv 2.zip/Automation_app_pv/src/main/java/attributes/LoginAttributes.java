package attributes;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebDriver;

public class LoginAttributes {

  //  @AndroidFindBy(accessibility = "imp_emaillogin")
    @AndroidFindBy(accessibility = "imp_emaillogin")
    @iOSFindBy(accessibility = "imp_emaillogin")
    protected MobileElement campoemail;

    @AndroidFindBy(accessibility = "imp_passwordlogin")
    @iOSFindBy(accessibility = "imp_passwordlogin")
    protected MobileElement camposenha;

    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"imp_passwordlogin\"]//android.view.View[@content-desc=\"*Campo obrigatório.\"]")
    protected MobileElement camposenhaObrigatorio;

    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"imp_emaillogin\"]//android.view.View[@content-desc=\"*Campo obrigatório.\"]")
    protected MobileElement campoEmailObrigatorio;

    @AndroidFindBy(accessibility = "btn_accessacount")
    @iOSFindBy(accessibility = "btn_accessacount")
    protected MobileElement botaologin;

    @AndroidFindBy(accessibility = "btn_rememberemail")
    protected MobileElement botaoLembrarEmail;

    @AndroidFindBy(accessibility = "btn_forgotpassword")
    protected MobileElement botaoEsqueciMinhaSenha;

    @AndroidFindBy(accessibility = "btn_recoverytoken")
    protected MobileElement botaoRecuperarToken;

    @AndroidFindBy(accessibility = "btn_tokens")
    protected MobileElement botaoTokens;

    @AndroidFindBy(accessibility = "btn_help")
    protected MobileElement botaoAjuda;

}
