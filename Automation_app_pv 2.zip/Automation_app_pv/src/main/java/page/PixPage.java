package page;

import attributes.PixAttributes;
import attributes.MenuAttributes;
import com.google.common.collect.ImmutableMap;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.touch.offset.PointOption;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Point;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.Pause;
import org.openqa.selenium.interactions.PointerInput;
import org.openqa.selenium.interactions.Sequence;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import utils.BasePage;
import utils.Utils;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import static java.time.Duration.ofMillis;
import static java.util.Collections.singletonList;
import static utils.Utils.driver;
import static utils.Utils.getPropertySettings;

public class PixPage extends PixAttributes {
    LocalDate myObj = LocalDate.now();

    public PixPage(AppiumDriver<?> driver) {
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }

    public void clicoEmTransferir() throws InterruptedException {
        BasePage.implicitWait(transferir, 10);
        transferir.click();
    }

    public void clicoEmQRCode() throws InterruptedException {
        BasePage.implicitWait(QRCode, 10);
        QRCode.click();
    }

    public void clicoEmContinuarDinheiroNaMaoComPixSaqueETroco() throws InterruptedException {
        BasePage.implicitWait(botaoContinuarDinheiroNaMaoPixSaqueTroco, 10);
        botaoContinuarDinheiroNaMaoPixSaqueTroco.click();
    }

    public void clicoEmContinuarJornadaPix() throws InterruptedException {

        try {
            BasePage.implicitWait(botaoContinuarJornadaPix, 10);
            botaoContinuarJornadaPix.click();
        }catch (NoSuchElementException e2) {
            BasePage.implicitWait(botaoContinuarJornadaPixOutraVersao, 10);
            botaoContinuarJornadaPixOutraVersao.click();
        }
    }

    public void clicoEmPixCopiaECola() throws InterruptedException {
        BasePage.implicitWait(pixCopiaECola, 10);
        pixCopiaECola.click();
    }

    public void clicoEmReceberPix() throws InterruptedException {
        BasePage.implicitWait(receberPix, 10);
        receberPix.click();
    }

    public void clicoEmExtratoPix() throws InterruptedException {
        BasePage.implicitWait(extratoPix, 10);
        extratoPix.click();
    }

    public void clicoEmContatosConfiaveisPix() throws InterruptedException {
        BasePage.implicitWait(contatos, 10);
        contatos.click();
    }

    public void clicoEmMinhasChavesPix() throws InterruptedException {
        BasePage.implicitWait(minhasChaves, 10);
        minhasChaves.click();
    }

    public void clicoContinuarSegurancaChavesPix() throws InterruptedException {
        BasePage.implicitWait(continuarSegurancaChavesPix, 10);
        continuarSegurancaChavesPix.click();
    }

    public void clicoEmLimitesPix() throws InterruptedException {
        BasePage.implicitWait(limites, 10);
        limites.click();
    }

    public void clicoEmReclameAquiPix() throws InterruptedException {

        //clica em limites e arrasta para o lado
        ((JavascriptExecutor) Utils.driver).executeScript("mobile: dragGesture", ImmutableMap.of(
                "elementId", ((RemoteWebElement) limites).getId(),
                "endX", limites.getLocation().x-30,
                "endY", limites.getLocation().y
        ));
        new Actions(Utils.driver).dragAndDrop(limites,extratoPix);
        reclameAquiPix.click();
    }

    public void clicoEmSelecioneAChave() throws InterruptedException {
        BasePage.implicitWait(botaoSelecioneAChave, 10);
        botaoSelecioneAChave.click();
    }

    public MobileElement transferirElemento() throws InterruptedException {
        BasePage.implicitWait(transferir, 10);
        return transferir;
    }

    public MobileElement primeiraChavePix() throws InterruptedException {
        BasePage.implicitWait(primeiraChavePix, 10);
        return primeiraChavePix;
    }

    public MobileElement qrCodeElemento() throws InterruptedException {
        BasePage.implicitWait(QRCode, 10);
        return QRCode;
    }

    public MobileElement pixCopiaEColaElemento() throws InterruptedException {
        BasePage.implicitWait(pixCopiaECola, 10);
        return pixCopiaECola;
    }

    public MobileElement receberElemento() throws InterruptedException {
        BasePage.implicitWait(receberPix, 10);
        return receberPix;
    }

    public MobileElement inputCodigoPix() throws InterruptedException {
        BasePage.implicitWait(inputCodigoPix, 10);
        return inputCodigoPix;
    }

    public MobileElement inputNovoQRCode() throws InterruptedException {
        BasePage.implicitWait(inputNovoQRCode, 10);
        return inputNovoQRCode;
    }

    public MobileElement botaoDigitarCodigoQRCode() throws InterruptedException {
        BasePage.implicitWait(botaoDigitarCodigoQRCode, 10);
        return botaoDigitarCodigoQRCode;
    }

    public MobileElement extratoElemento() throws InterruptedException {
        BasePage.implicitWait(extratoPix, 10);
        return extratoPix;
    }

    public MobileElement contatosConfiaveisElemento() throws InterruptedException {
        BasePage.implicitWait(contatos, 10);
        return contatos;
    }

    public MobileElement minhasChavesElemento() throws InterruptedException {
        BasePage.implicitWait(minhasChaves, 10);
        return minhasChaves;
    }

    public MobileElement limitesElemento() throws InterruptedException {
        BasePage.implicitWait(limites, 10);
        return limites;
    }

    public MobileElement lancamentosExtratoPix() throws InterruptedException {
        BasePage.implicitWait(lancamentosExtratoPix, 10);
        return lancamentosExtratoPix;
    }

    public MobileElement limitePessoasPix() throws InterruptedException {
        BasePage.implicitWait(limitePessoasPix, 10);
        return limitePessoasPix;
    }

    public MobileElement opcaoAtendimentoReclamePixPagueVeloz() throws InterruptedException {
        BasePage.implicitWait(opcaoAtendimentoReclamePixPagueVeloz, 10);
        return opcaoAtendimentoReclamePixPagueVeloz;
    }

    public MobileElement opcaoAtendimentoReclamePixBancoCentralBrasil() throws InterruptedException {
        BasePage.implicitWait(opcaoAtendimentoReclamePixBancoCentralBrasil, 10);
        return opcaoAtendimentoReclamePixBancoCentralBrasil;
    }

    public MobileElement limiteEmpresasPix() throws InterruptedException {
        BasePage.implicitWait(limiteEmpresasPix, 10);
        return limiteEmpresasPix;
    }

    public MobileElement limiteContatosConfiaveisPix() throws InterruptedException {
        BasePage.implicitWait(limiteContatosConfiaveisPix, 10);
        return limiteContatosConfiaveisPix;
    }

    public MobileElement limiteGestaoHorariosPix() throws InterruptedException {
        BasePage.implicitWait(limiteGestaoHorariosPix, 10);
        return limiteGestaoHorariosPix;
    }

    public MobileElement limiteSaqueETrocoPix() throws InterruptedException {
        BasePage.implicitWait(limiteSaqueETrocoPix, 10);
        return limiteSaqueETrocoPix;
    }

    public MobileElement futurosExtratoPix() throws InterruptedException {
        BasePage.implicitWait(futurosExtratoPix, 10);
        return futurosExtratoPix;
    }

    public MobileElement todosExtratoPix() throws InterruptedException {
        BasePage.implicitWait(todosExtratoPix, 10);
        return todosExtratoPix;
    }

    public MobileElement entradasExtratoPix() throws InterruptedException {
        BasePage.implicitWait(entradasExtratoPix, 10);
        return entradasExtratoPix;
    }

    public MobileElement saidasExtratoPix() throws InterruptedException {
        BasePage.implicitWait(saidasExtratoPix, 10);
        return saidasExtratoPix;
    }

    public MobileElement contatosConfiaveisPix() throws InterruptedException {
        BasePage.implicitWait(contatosConfiaveisPix, 10);
        return contatosConfiaveisPix;
    }

    public void clicoEmTipoChaveCPF() throws InterruptedException {
        BasePage.implicitWait(tipoChaveCPF, 10);
        tipoChaveCPF.click();
    }

    public void clicoEmPesquisarChavePix() throws InterruptedException {
        BasePage.implicitWait(pesquisarChavePix, 10);
        pesquisarChavePix.click();
    }

    public boolean possuiOpcoesDeTipoDeChave() {
        try{
            BasePage.implicitWait(tipoChaveAleatoria, 10);
            BasePage.implicitWait(tipoChaveEmail, 10);
            BasePage.implicitWait(tipoChaveCNPJ, 10);
            BasePage.implicitWait(tipoChaveCPF, 10);
            BasePage.implicitWait(tipoChaveCelular, 10);
            BasePage.implicitWait(tipoChaveManual, 10);
            return true;
        }catch (NoSuchElementException e){
            return false;
        }
    }

    public void digitoCpfChavePix() throws InterruptedException {
        Actions action = new Actions(driver);
        // Mova o mouse para o elemento e clique nele
        action.moveToElement(campoChavePix).click().perform();
        WebDriverWait espera = new WebDriverWait(driver, 10); // 10 segundos de tempo máximo de espera
        espera.until(ExpectedConditions.elementToBeClickable(campoChavePix));

        String texto = getPropertySettings("cpfpix");
        for (char c : texto.toCharArray()) {
            // Envie a tecla atual
            action.sendKeys(Character.toString(c)).perform();
            // Aguarde um pequeno intervalo de tempo (100 milissegundos neste exemplo)
            Thread.sleep(100);
        }

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    public void confirmoODestinatarioPix() {
        BasePage.implicitWait(confirmoODestinatarioPix, 10);
        confirmoODestinatarioPix.click();
    }

    public void colocoOValorPix(String valor) throws InterruptedException {

        Actions action = new Actions(driver);
        // Mova o mouse para o elemento e clique nele
        action.moveToElement(campoValorPix).click().perform();
        WebDriverWait espera = new WebDriverWait(driver, 10); // 10 segundos de tempo máximo de espera
        espera.until(ExpectedConditions.elementToBeClickable(campoValorPix));
        
        for (char c : valor.toCharArray()) {
            // Envie a tecla atual
            action.sendKeys(Character.toString(c)).perform();
            // Aguarde um pequeno intervalo de tempo (100 milissegundos neste exemplo)
            Thread.sleep(100);
        }
    }

    public void confirmoATransferenciaPix() {
        BasePage.implicitWait(confirmoATransferenciaPix, 10);
        confirmoATransferenciaPix.click();
    }

    public MobileElement mensagemPagamentoEfetuadoComSucesso() {
        BasePage.implicitWait(mensagemPagamentoEfetuadoComSucesso, 20);
        return mensagemPagamentoEfetuadoComSucesso;
    }

    public MobileElement valorComprovantePagamento() {
        BasePage.implicitWait(valorComprovantePagamento, 20);
        return valorComprovantePagamento;
    }

    public MobileElement nomeDestinatarioYuriAlves() {
        BasePage.implicitWait(nomeDestinatarioYuriAlves, 20);
        return nomeDestinatarioYuriAlves;
    }

    public MobileElement nomePagadorPremierSoft() {
        BasePage.implicitWait(nomePagadorPremierSoft, 20);
        return nomePagadorPremierSoft;
    }

    public void clicoNaMensagemPagamentoEfetuadoComSucesso() {
        BasePage.implicitWait(botaoOkEfetuadoComSucesso, 20);
        botaoOkEfetuadoComSucesso.click();
    }
}