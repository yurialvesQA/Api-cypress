package page;

import attributes.MenuAttributes;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import utils.BasePage;

import java.time.LocalDate;

public class MenuPage extends MenuAttributes {
    LocalDate myObj = LocalDate.now();

    public MenuPage(AppiumDriver<?> driver) {
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }

    public void irParaExtrato() throws InterruptedException {
        BasePage.implicitWait(extrato, 10);
        extrato.click();
    }

    public void irParaPix() throws InterruptedException {
        BasePage.implicitWait(pix, 10);
        pix.click();
    }

    public void irParaPagamentos() throws InterruptedException {
        BasePage.implicitWait(pagamentos, 10);
        pagamentos.click();
    }
}
