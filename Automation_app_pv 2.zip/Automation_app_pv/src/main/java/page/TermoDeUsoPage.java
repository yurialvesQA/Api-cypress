package page;

import attributes.TermoDeUsoAttributes;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import utils.BasePage;

import java.time.LocalDate;

import static utils.Utils.getPropertySettings;

public class TermoDeUsoPage  extends TermoDeUsoAttributes {

    LocalDate myObj = LocalDate.now();

    public TermoDeUsoPage(AppiumDriver<?> driver) {
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }

    public void clicarBotaoAceitar() throws InterruptedException {
        BasePage.implicitWait(botaoAceitar, 10);
        botaoAceitar.click();
    }

    public void clicarBotaoRecusar() throws InterruptedException {
        BasePage.implicitWait(botaoRecusar, 10);
        botaoRecusar.click();
    }

    public void botaoConfirmarAcaoNegar() throws InterruptedException {
        BasePage.implicitWait(botaoConfirmarAcaoNegar, 10);
        botaoConfirmarAcaoNegar.click();
    }
}
