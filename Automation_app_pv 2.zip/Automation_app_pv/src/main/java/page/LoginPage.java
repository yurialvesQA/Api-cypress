package page;

import attributes.LoginAttributes;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.touch.offset.ElementOption;
import io.appium.java_client.touch.offset.PointOption;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import utils.BasePage;
import utils.Utils;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;

import static org.junit.Assert.assertTrue;
import static utils.Utils.driver;
import static utils.Utils.getPropertySettings;

public class LoginPage  extends LoginAttributes {

    LocalDate myObj = LocalDate.now();


    public LoginPage(AppiumDriver<?> driver) {

        PageFactory.initElements(new AppiumFieldDecorator(driver), this);


    }

    /**
     * Metodo a ser chamado pela classe LoginSteps, no qual contem os metodos para
     * preencher email e senha
     */
    public void emailLogin() throws InterruptedException {

       BasePage.implicitWait(campoemail, 20);
        campoemail.click();

        Thread.sleep(200);

     //   driver.findElementByAccessibilityId("imp_emaillogin").sendKeys("yuhghghri.alves@br.experian.com");
        assertTrue(campoemail.isDisplayed());
        Actions action = new Actions(driver);
        // Mova o mouse para o elemento e clique nele
        action.moveToElement(campoemail).click().perform();
        WebDriverWait espera = new WebDriverWait(driver, 10); // 10 segundos de tempo máximo de espera
        espera.until(ExpectedConditions.elementToBeClickable(campoemail));
       action.sendKeys("yuri.alves@br.experian.com").perform();
       // campoemail.sendKeys( getPropertySettings("PvMobile.data.emailuser"));
       // action.sendKeys(getPropertySettings("PvMobile.data.emailuser")).perform();

       // setText(campoemail, getPropertySettings("PvMobile.data.emailuser"));
        Thread.sleep(1000);
    }

    public void emailLoginTransferencia() throws InterruptedException {

        BasePage.implicitWait(campoemail, 20);
        campoemail.click();
        Thread.sleep(200);

        Actions action = new Actions(driver);
        // Mova o mouse para o elemento e clique nele
        action.moveToElement(campoemail).click().perform();
        WebDriverWait espera = new WebDriverWait(driver, 10); // 10 segundos de tempo máximo de espera
        espera.until(ExpectedConditions.elementToBeClickable(campoemail));
        action.sendKeys(getPropertySettings("PvMobile.data.emailuser2")).perform();
        Thread.sleep(1000);
    }

    public void emailLoginTermoDeUso() throws InterruptedException {

        BasePage.implicitWait(campoemail, 20);
        campoemail.click();
        Thread.sleep(200);

        Actions action = new Actions(driver);
        // Mova o mouse para o elemento e clique nele
        action.moveToElement(campoemail).click().perform();
        WebDriverWait espera = new WebDriverWait(driver, 10); // 10 segundos de tempo máximo de espera
        espera.until(ExpectedConditions.elementToBeClickable(campoemail));
        action.sendKeys(getPropertySettings("PvMobile.data.email.usertermodeuso")).perform();
        Thread.sleep(1000);
    }


    /**
     * Metodo a ser chamado pela classe clientSteps, no qual contem o metodo para
     * preencher o Campo Senha
     */
    public void passwordLogin() {

        camposenha.click();
        //camposenha.sendKeys(getPropertySettings("PvMobile.data.passworuser"));
        Actions action = new Actions(driver);
        action.sendKeys(getPropertySettings("PvMobile.data.passworuser")).perform();
        //  camposenha.sendKeys(getPropertySettings("PvMobile.data.passworuser"));
        //setText(camposenha, getPropertySettings("PvMobile.data.passworuser"));
    }

    public void passwordLoginTransferencia() {
        camposenha.click();
        Actions action = new Actions(driver);
        action.sendKeys(getPropertySettings("PvMobile.data.passworuser2")).perform();
    }

    public void passwordLoginTermoDeUso() {
        camposenha.click();
        Actions action = new Actions(driver);
        action.sendKeys(getPropertySettings("PvMobile.data.password.passwordtermodeuso")).perform();
    }


    /**
     * Metodo a ser chamado pela classe clientSteps, no qual contem o metodo para
     * selecionar Cliente
     */
    public void confirmarLogin() throws InterruptedException {
        BasePage.implicitWait(botaologin, 10);
        botaologin.click();
        BasePage.fixedWait(6);

    }

    public void clicarLembrarEmail() throws InterruptedException {
        BasePage.implicitWait(botaoLembrarEmail, 10);
        botaoLembrarEmail.click();
        BasePage.fixedWait(6);

    }

    /**
     * Metodo a ser chamado pela classe clientSteps, no qual contem o metodo para
     * verificar campo senha obrigatorio
     */
    public MobileElement mensagemCampoSenhaObrigatorio() throws InterruptedException {
        BasePage.implicitWait(camposenhaObrigatorio, 10);
       return camposenhaObrigatorio;
    }

    /**
     * Metodo a ser chamado pela classe clientSteps, no qual contem o metodo para
     * verificar campo email obrigatorio
     */
    public MobileElement mensagemCampoEmailObrigatorio() throws InterruptedException {
        BasePage.implicitWait(campoEmailObrigatorio, 10);
        return campoEmailObrigatorio;
    }

    public void irParaPaginaEsqueciMinhaSenha() throws InterruptedException {
        BasePage.implicitWait(botaoEsqueciMinhaSenha, 10);
        botaoEsqueciMinhaSenha.click();
        BasePage.fixedWait(6);
    }

    public void irParaPaginaRecuperarToken() throws InterruptedException {
        BasePage.implicitWait(botaoRecuperarToken, 10);
        //JavascriptExecutor js = (JavascriptExecutor) driver;

       // js.executeScript("arguments[0].click();", botaoRecuperarToken);
        //MobileElement el = (MobileElement) driver.findElement(MobileBy.AndroidUIAutomator("new UiSelector().description(\"btn_recoverytoken\")"));
        //el.click();
       botaoRecuperarToken.click();

        BasePage.fixedWait(6);
    }

    public void irParaPaginaTokens() throws InterruptedException {
        BasePage.implicitWait(botaoTokens, 10);
        botaoTokens.click();
        BasePage.fixedWait(6);
    }


}
