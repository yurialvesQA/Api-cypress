package page;

import attributes.DocumentosPendentesAttributes;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import utils.BasePage;

import java.time.LocalDate;

public class DocumentosPendentesPage  extends DocumentosPendentesAttributes {

    LocalDate myObj = LocalDate.now();

    public DocumentosPendentesPage(AppiumDriver<?> driver) {
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }

    public MobileElement campoEnviarDepois() throws InterruptedException {
        BasePage.implicitWait(enviarDepois, 10);
        return enviarDepois;
    }

    public MobileElement clicarEnviarDepois() throws InterruptedException {
        BasePage.implicitWait(enviarDepois, 10);
        enviarDepois.click();
        return enviarDepois;
    }
}
